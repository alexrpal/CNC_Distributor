﻿using System;
using System.IO;

namespace Program_Sorter
{
    class Program
    {
        static void Main()
        {
            string file_start_location = @"P:\PROGRAM DATABASE\LATHES\HAAS SL20\MACHINE BACKUP_3_4_20.txt";
            string line; 
            string fileH = "O0000";
            int number_of_prog = 0;

            using (StreamReader file = new StreamReader(file_start_location))
            {
                while ((line = file.ReadLine()) != null)
                {
                    if (line != "")
                    {
                        string title8 = line.Replace("\\", "_");
                        string title7 = title8.Replace("*", "_");
                        string title6 = title7.Replace(":", "_");
                        string title5 = title6.Replace("?", "_");
                        string title4 = title5.Replace("<", "_");
                        string title3 = title4.Replace(">", "_");
                        string title2 = title3.Replace("|", "_");
                        string title1 = title2.Replace("\"", "_");
                        string title = title1.Replace("/", "_");
                        string test_O = "O";
                        string fileName = @"P:\PROGRAM DATABASE\LATHES\HAAS SL20\" + fileH + ".txt";
                        if (test_O[0].Equals(line[0]))
                        {
                            using (StreamWriter newFile = new StreamWriter(fileName, true))
                            {
                                Console.WriteLine("%");
                                newFile.WriteLine("%");
                            }
                            fileName = @"P:\PROGRAM DATABASE\LATHES\HAAS SL20\" + title + ".txt";
                            using (FileStream fs = File.Create(fileName)) { };
                            using (StreamWriter newFile = new StreamWriter(fileName))
                            {
                                Console.WriteLine(line);
                                newFile.WriteLine(title);
                            }
                            number_of_prog++;
                            fileH = title;
                        }
                        else
                        {
                            using (StreamWriter newFile = new StreamWriter(fileName, true))
                            {
                                Console.WriteLine(line);
                                newFile.WriteLine(title);
                            }
                        }
                    }
                };
                file.Close();
                Console.WriteLine("There are " + number_of_prog + " programs.");
                Console.ReadLine();
            }
        }
    }
}
